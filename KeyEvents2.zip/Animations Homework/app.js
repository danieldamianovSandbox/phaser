'use strict'
const game = new Phaser.Game(
    800,800,Phaser.AUTO,"",{preload,create,update}
)

function preload()
{

    loadResources();

}

function loadResources() {
    game.load.spritesheet('pic', 'pictures\\magic.png', 512 / 8, 512 / 8);
    game.load.image('background', 'pictures\\back.jpg');
}

function loadBackGround()
{
    game.add.tileSprite(0, 0, 800, 800, 'background');
}

var pic;
function create()
{
    loadBackGround();
    InitializeAnimations();
    pic.animations.play('walkRight', 8, true);

    cursors = game.input.keyboard.createCursorKeys();

}
var cursors;
var movingDirection = 0;//0-right,
                        //1-left
                        //2-up
                        //3-down

function InitializeAnimations() {
    pic = game.add.sprite(0, 0, 'pic');
    pic.scale.setTo(3);
    var walkLeft = pic.animations.add('walkLeft', [4,5,6,7,12,13,14,15,20,21,22,23,28,29,30,31]);
    var walkUp = pic.animations.add('walkUp', [32,33,34,35,40,41,42,43,48,49,50,51,56,57,58,59]);
    var walkDown = pic.animations.add('walkDown', [0, 1, 2, 3,8,9,10,11,16,17,18,19,24,25,26,27]);
    var walkRight = pic.animations.add('walkRight', [36,37,38,39,44,45,46,47,52,53,54,55,60,61,62,63]);
    

    
}
var hasMoved;
function update()
{
    hasMoved = false;
    handleExitingScreenToTheRight();
    if(hasMoved == false)
    {
        handleExitingScreenToTheUp();
    }
    if(hasMoved == false)
    {
        handleExitingScreenToTheDown();
    }
    if(hasMoved == false)
    {
        handleExitingScreenToTheLeft();
    }

    if (cursors.up.isDown)
    {
        movingDirection = 2;
        hasMoved = true;
        pic.animations.play('walkUp', 8, true);
    }
    else if (cursors.down.isDown)
    {
        hasMoved = true;
        //pic.x = -150;
        movingDirection = 3;
        //pic.x -= 10;
        pic.animations.play('walkDown',8, true);
    }
    //console.log('asdasd');
    if (cursors.left.isDown)
    {
        hasMoved = true;
        movingDirection = 1;
        //pic.y -= 10;
        pic.animations.play('walkLeft', 8, true);
    }
    else if (cursors.right.isDown)
    {
        hasMoved = true;
        movingDirection = 0;
        pic.animations.play('walkRight', 8, true);
    }

    moveSprite();

}

function moveSprite() {
    if(hasMoved == false)
    {
        pic.animations.stop();
    return;
    }
    
    if (movingDirection == 0)
        pic.x += 4;
    else  if (movingDirection == 1)
        pic.x -= 4;
    else  if (movingDirection == 2)
        pic.y -= 4;
    else  if (movingDirection == 3)
        pic.y += 4;
}

function handleExitingScreenToTheLeft() {
    if (pic.x < 0) {
        movingDirection = 2;
        pic.x = 0;
        hasMoved = true;
        pic.animations.play('walkUp', 8, true);
        //moveSprite();
    }
}

function handleExitingScreenToTheUp()
{
    if (pic.y < 0) {
        hasMoved = true;
        movingDirection = 0;
        pic.y = 0;
        pic.animations.play('walkRight', 8, true);
        //moveSprite()
    }
}

function handleExitingScreenToTheDown()
{
    if (pic.y + pic.height> game.height) {
        hasMoved = true;
        movingDirection = 1;
        pic.y -= 4;
        pic.animations.play('walkLeft', 8, true);
        //moveSprite()
    }
}

function handleExitingScreenToTheRight() {
    if (pic.x + pic.width> game.width) {
        hasMoved = true;
        //pic.x = -150;
        movingDirection = 3;
        pic.x -= 4;
        pic.animations.play('walkDown',8, true);
        //moveSprite();
    }
}
