'use strict'

const game = new Phaser.Game(
    1000,
    1000,
    Phaser.AUTO,
    '',
    { preload, create, update }
);

var map;
var layer;
var player;
var cursors;

function preload() 
{
    cursors = game.input.keyboard.createCursorKeys();

    game.load.image('player','./assets/player.png');

    game.load.image('tileset','./assets\\32x32_tileset_mario.png');

    game.load.tilemap('map','./assets/map.json',null,Phaser.Tilemap.TILED_JSON);
}

function create() 
{
    game.stage.backgroundColor = '#AAAAAA';
    map = game.add.tilemap('map')
    map.addTilesetImage('32x32_tileset_mario','tileset');
    layer = map.createLayer(0)
    layer.resizeWorld()

    player = game.add.sprite(32,32,'player')
    player.scale.setTo(0.03)
    game.physics.enable(player)
    map.setCollision([871],true,layer);
}

function update() 
{
    if (cursors.up.isDown)
    {
        player.body.y -= 5;
    }
    if (cursors.down.isDown)
    {
        player.body.y += 5;
    }
    if (cursors.left.isDown)
    {
        player.body.x -= 5;
    }
    if (cursors.right.isDown)
    {
        player.body.x += 5;
    }

    game.physics.arcade.collide(player,layer,() =>  {

    })
}