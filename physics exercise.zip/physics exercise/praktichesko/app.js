'use strict'

const game = new Phaser.Game(
    800,
    800,
    Phaser.AUTO,
    '',
    { preload, create, update }
);


function preload() {
    game.load.image('sphere', './assets/sphere.jpg');
    game.load.image('background', 'assets\\back.jpg');
    game.load.spritesheet('dude', 'assets\\dude.png',288/9,40);
}

var sphere1;

var ball;
var dude;
var cursors;


function create() {
    loadBackGround();
    cursors = game.input.keyboard.createCursorKeys();
    ball = game.add.sprite(300,300,"sphere")
    ball.scale.setTo(0.05)
    game.physics.enable(ball);
    ball.body.gravity.x = 50;
    ball.body.collideWorldBounds = true;
    ball.body.bounce.setTo(1.01);;
    
    dude = game.add.sprite(0,0,"dude")
    game.physics.enable(dude);
    dude.frame = 1;
    dude.body.collideWorldBounds = true;
    
}
function loadBackGround()
{
    game.add.tileSprite(0, 0, 800, 800, 'background');
    
}

function update() {
    dude.body.velocity.y = 0;
    dude.body.velocity.x = 0;
    if (cursors.up.isDown)
    {
        dude.body.velocity.y -= 500;
    }
    if (cursors.down.isDown)
    {
        dude.body.velocity.y += 500;
    }
    if (cursors.left.isDown)
    {
        dude.body.velocity.x -= 500;
    }
    if (cursors.right.isDown)
    {
        dude.body.velocity.x += 500;
    }

    game.physics.arcade.collide(dude,ball);
};

