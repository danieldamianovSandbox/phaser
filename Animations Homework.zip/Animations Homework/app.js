'use strict'
const game = new Phaser.Game(
    800,800,Phaser.AUTO,"",{preload,create,update}
)

function preload()
{

    loadResources();
    
}

function loadResources() {
    game.load.spritesheet('pic', 'pictures\\magic.png', 512 / 8, 512 / 8);
    game.load.spritesheet('coin', 'pictures\\MonedaP.png', 80 / 5, 16);
    game.load.image('background', 'pictures\\back.jpg');
    game.load.image('stena', 'pictures\\stena.png');
}

function loadBackGround()
{
    game.add.tileSprite(0, 0, 800, 800, 'background');
}
var stena1;
var stena2;
var stena3;
var stena4;
function loadWalls()
{
    stena1 = game.add.sprite(300, 400, 'stena');
    stena1.scale.setTo(4);
    stena2 = game.add.sprite(364, 400, 'stena');
    stena2.scale.setTo(4);
    stena3 = game.add.sprite(428, 400, 'stena');
    stena3.scale.setTo(4);
    stena4 = game.add.sprite(474, 400, 'stena');
    stena4.scale.setTo(4);
}

var pic;
var coin;

function create()
{
    
    loadBackGround();
    loadWalls();
    InitializeAnimations();
    pic.animations.play('walkRight', 8, true);

    cursors = game.input.keyboard.createCursorKeys();

}
var cursors;
var movingDirection = 0;//0-right,
                        //1-left
                        //2-up
                        //3-down

function InitializeAnimations() {
    pic = game.add.sprite(0, 0, 'pic');
    pic.scale.setTo(2);
    var walkLeft = pic.animations.add('walkLeft', [4,5,6,7,12,13,14,15,20,21,22,23,28,29,30,31]);
    var walkUp = pic.animations.add('walkUp', [32,33,34,35,40,41,42,43,48,49,50,51,56,57,58,59]);
    var walkDown = pic.animations.add('walkDown', [0, 1, 2, 3,8,9,10,11,16,17,18,19,24,25,26,27]);
    var walkRight = pic.animations.add('walkRight', [36,37,38,39,44,45,46,47,52,53,54,55,60,61,62,63]);

    coin = game.add.sprite(300, 300, 'coin');
    coin.scale.setTo(5);
    var anime = coin.animations.add('anime', [0,1,2,3,4]);
    coin.animations.play('anime',10,true);
    
}
var hasMoved;
var hasExited;

function touchesWalls()
{
    var sprites = [stena1,stena2,stena3,stena4,];
    var flag = false;
    sprites.forEach(element => {
        if(overlap(pic,element))
        {
            flag = true;
        }
    });
    return flag;
}
var jumpFactor = -5;
var currentY;
var up = true;
function update()
{
    if(game.input.keyboard.isDown(Phaser.Keyboard.SPACEBAR) && jumpFactor != 0)
    {
        console.log('asdasd');
        if(jumpFactor == 50)
        {
            up = false;
        }
        if(up) jumpFactor+=5;
        else jumpFactor-=5;

        if(jumpFactor == 0)
        {
            up = true;
        }
        // // else if(jumpFactor >= 0)
        // // {
        // //     jumpFactor +=1;
        // // }
        // // if(jumpFactor < 0)
        // // {
        // //     jumpFactor = 0;
        // // }
        pic.y = currentY - jumpFactor;
    }
    else
    {
        currentY = pic.y;
        up = true;
        jumpFactor = -5;   
    }
    
    hasMoved =false;
    
    if(hasMoved == false)
    {
        handleExitingScreenToTheRight();
    }
    if(hasMoved == false)
    {
        handleExitingScreenToTheUp();
    }
    if(hasMoved == false)
    {
        handleExitingScreenToTheDown();
    }
    if(hasMoved == false)
    {
        handleExitingScreenToTheLeft();
    }
    
    
    if (cursors.up.isDown)
    {
        movingDirection = 2;
        hasMoved = true;
        pic.animations.play('walkUp', 8, true);
    }
    else if (cursors.down.isDown)
    {
        hasMoved = true;
        movingDirection = 3;

        pic.animations.play('walkDown',8, true);
    }
    //console.log('asdasd');
    if (cursors.left.isDown)
    {
        hasMoved = true;
        movingDirection = 1;
        //pic.y -= 10;
        pic.animations.play('walkLeft', 8, true);
    }
    else if (cursors.right.isDown)
    {
        hasMoved = true;
        movingDirection = 0;
        pic.animations.play('walkLeft', 8, true);
    }

    


    moveSprite();

    checkForEatingTheCoin();

}

const overlap = function(sprite1,sprite2)
{
    if(sprite1.x < sprite2.x + sprite2.width
        && sprite1.y < sprite2.y + sprite2.height
        && sprite1.x + sprite1.width > sprite2.x
        && sprite1.y + sprite1.height > sprite2.y)
        {
            return 1;
        }

}

function checkForEatingTheCoin()
{
    if(overlap(pic,coin))
    {   
        coin.x = game.rnd.integerInRange(0,700);
        coin.y = game.rnd.integerInRange(0,700);
    }
}

function moveSprite() {
    if(hasMoved == false)
    {
         pic.animations.stop();
     return;
     }
    


    if (movingDirection == 0)
        pic.x += 4;
    else  if (movingDirection == 1)
        pic.x -= 4;
    else  if (movingDirection == 2)
        pic.y -= 4;
    else  if (movingDirection == 3)
        pic.y += 4;

    if(touchesWalls())
    {
        if (movingDirection == 0)
        pic.x -= 4;
    else  if (movingDirection == 1)
        pic.x += 4;
    else  if (movingDirection == 2)
        pic.y += 4;
    else  if (movingDirection == 3)
        pic.y -= 4;
    }
}

function handleExitingScreenToTheLeft() {
    if (pic.x < 0) {
        pic.x = 0;
        hasMoved = true;
    }
}

function handleExitingScreenToTheUp()
{
    if (pic.y < 0) {
        hasMoved = true;
        pic.y = 0;
    }
}

function handleExitingScreenToTheDown()
{
    if (pic.y + pic.height> game.height) {
        hasMoved = true;
        pic.y -= 4;
    }
}

function handleExitingScreenToTheRight() {
    if (pic.x + pic.width> game.width) {
        hasMoved = true;
        pic.x -= 4;
    }
}
