'use strict'
const game = new Phaser.Game(
    800,800,Phaser.AUTO,"",{preload,create,update}
)

function preload()
{

    loadResources();
    
}

function loadResources() {
    game.load.spritesheet('pic', 'pictures\\magic.png', 512 / 8, 512 / 8);
    game.load.spritesheet('pic2', 'pictures\\pic2.png', 1142 / 12, 635 / 4);
    game.load.spritesheet('coin', 'pictures\\MonedaP.png', 80 / 5, 16);
    game.load.spritesheet('coin2', 'pictures\\MonedaD.png', 80 / 5, 16);
    game.load.spritesheet('enemy', 'pictures\\enemy.png', 350 / 7, 407/11);
    game.load.image('background', 'pictures\\back.jpg');
    game.load.image('stena', 'pictures\\stena.png');
}

function loadBackGround()
{
    game.add.tileSprite(0, 0, 800, 800, 'background');
}
var stena1;
var stena2;
var stena3;
var stena4;
function loadWalls()
{
    stena1 = game.add.sprite(300, 400, 'stena');
    stena1.scale.setTo(4);
    stena2 = game.add.sprite(364, 400, 'stena');
    stena2.scale.setTo(4);
    stena3 = game.add.sprite(428, 400, 'stena');
    stena3.scale.setTo(4);
    stena4 = game.add.sprite(474, 400, 'stena');
    stena4.scale.setTo(4);
}

var pic;
var pic2;
var enemy;
var coin;
var coin2;

function create()
{
    
    loadBackGround();
    loadWalls();
    InitializeAnimations();
    pic.animations.play('walkRight', 8, true);
    pic2.animations.play('walkRight', 8, true);
    enemy.animations.play('walk', 8, true);

    cursors = game.input.keyboard.createCursorKeys();

}
var cursors;
var movingDirection = 0;//0-right,
                        //1-left
                        //2-up
                        //3-down

function InitializeAnimations() {
    pic = game.add.sprite(0, 0, 'pic');
    pic2 = game.add.sprite(100, 0, 'pic2');
    enemy = game.add.sprite(500, 500, 'enemy');

    pic2.scale.setTo(0.5);
    pic.scale.setTo(1);
    enemy.scale.setTo(2);

    var walkLeft = pic.animations.add('walkLeft', [4,5,6,7,12,13,14,15,20,21,22,23,28,29,30,31]);
    var walkUp = pic.animations.add('walkUp', [32,33,34,35,40,41,42,43,48,49,50,51,56,57,58,59]);
    var walkDown = pic.animations.add('walkDown', [0, 1, 2, 3,8,9,10,11,16,17,18,19,24,25,26,27]);
    var walkRight = pic.animations.add('walkRight', [36,37,38,39,44,45,46,47,52,53,54,55,60,61,62,63]);

    var walkLeft2 = pic2.animations.add('walkDown', [0,1,2,3,4,5,6,7,8,9,10,11]);
    var walkUp2 = pic2.animations.add('walkLeft', [11,12,13,14,15,16,17,18,19,20,21,22,23]);
    var walkDown2 = pic2.animations.add('walkRight', [24,25,26,27,28,29,30,31,32,33,34,35]);
    var walkRight2 = pic2.animations.add('walkUp', [36,37,38,39,40,41,42,43,44,45,46,47]);

    var walk = enemy.animations.add('walk',[0,1,2,3,7,8,9,10,11,12,13,14,15,16]);

    coin = game.add.sprite(300, 300, 'coin');
    coin.scale.setTo(5);
    var anime = coin.animations.add('anime', [0,1,2,3,4]);
    coin.animations.play('anime',10,true);
    
    coin2 = game.add.sprite(400, 400, 'coin2');
    coin2.scale.setTo(5);
    var anime = coin2.animations.add('anime', [0,1,2,3,4]);
    coin2.animations.play('anime',10,true);
}
var hasMoved;
var hasExited;

function touchesWalls(sprite)
{
    var sprites = [stena1,stena2,stena3,stena4,];
    var flag = false;
    sprites.forEach(element => {
        if(overlap(sprite,element))
        {
            flag = true;
        }
    });
    return flag;
}
var jumpFactor = 0;
var currentY;
var up = true;
var isJumping = false;
var picCoins = 0;
    var pic2Coins = 0;
function update()
{
    if(game.input.keyboard.isDown(Phaser.Keyboard.SPACEBAR) || isJumping)
    {
        console.log('asdasd');
        if(jumpFactor == 50)
        {
            up = false;
        }
        if(up) 
        {
            jumpFactor+=5;isJumping = true;
        }
        else {
            jumpFactor-=5;isJumping = true;
        }

        if(jumpFactor == 0 && isJumping == false)
        {
            up = true;
        }
        else if(jumpFactor == 0 && isJumping == true)
        {
            isJumping = false;
        }
        // // else if(jumpFactor >= 0)
        // // {
        // //     jumpFactor +=1;
        // // }
        // // if(jumpFactor < 0)
        // // {
        // //     jumpFactor = 0;
        // // }
        pic.y = currentY - jumpFactor;
        
    }
    else
    {
        currentY = pic.y;
        up = true;
        jumpFactor = 0;
        isJumping = false;   
    }
    
    hasMoved =false;
    
    if(hasMoved == false)
    {
        handleExitingScreenToTheRight(pic);
    }
    if(hasMoved == false)
    {
        handleExitingScreenToTheUp(pic);
    }
    if(hasMoved == false)
    {
        handleExitingScreenToTheDown(pic);
    }
    if(hasMoved == false)
    {
        handleExitingScreenToTheLeft(pic);
    }
    
    
    if (cursors.up.isDown)
    {
        movingDirection = 2;
        hasMoved = true;
        pic.animations.play('walkUp', 8, true);
    }
    else if (cursors.down.isDown)
    {
        hasMoved = true;
        movingDirection = 3;

        pic.animations.play('walkDown',8, true);
    }
    //console.log('asdasd');
    if (cursors.left.isDown)
    {
        hasMoved = true;
        movingDirection = 1;
        //pic.y -= 10;
        pic.animations.play('walkLeft', 8, true);
    }
    else if (cursors.right.isDown)
    {
        hasMoved = true;
        movingDirection = 0;
        pic.animations.play('walkLeft', 8, true);
    }

    
    

    moveSprite(pic);

    if(checkForEatingTheCoin(pic,coin2))
    {  
         picCoins = picCoins + 1;
        console.log('Magician Coins: ' +  picCoins);
    }











    hasMoved =false;
    
    if(hasMoved == false)
    {
        handleExitingScreenToTheRight(pic2);
    }
    if(hasMoved == false)
    {
        handleExitingScreenToTheUp(pic2);
    }
    if(hasMoved == false)
    {
        handleExitingScreenToTheDown(pic2);
    }
    if(hasMoved == false)
    {
        handleExitingScreenToTheLeft(pic2);
    }
    
    
    if (game.input.keyboard.isDown(Phaser.Keyboard.W))
    {
        movingDirection = 2;
        hasMoved = true;
        pic2.animations.play('walkUp', 8, true);
    }
    else if (game.input.keyboard.isDown(Phaser.Keyboard.S))
    {
        hasMoved = true;
        movingDirection = 3;

        pic2.animations.play('walkDown',8, true);
    }
    //console.log('asdasd');
    if (game.input.keyboard.isDown(Phaser.Keyboard.A))
    {
        hasMoved = true;
        movingDirection = 1;
        //pic.y -= 10;
        pic2.animations.play('walkLeft', 8, true);
    }
    else if (game.input.keyboard.isDown(Phaser.Keyboard.D))
    {
        hasMoved = true;
        movingDirection = 0;
        pic2.animations.play('walkLeft', 8, true);
    }

    


    moveSprite(pic2);



    if(checkForEatingTheCoin(pic2,coin))
    {
        pic2Coins++;
        console.log('Person Coins: ' +  pic2Coins);
    }

    var picToenemyHoriz = pic.x - enemy.x;

    var picToenemyVertic = pic.y - enemy.y;

    var picToenemyHoriz2 = pic2.x - enemy.x;

    var picToenemyVertic2 = pic2.y - enemy.y;

    if(Math.sqrt(picToenemyVertic * picToenemyVertic + picToenemyHoriz * picToenemyHoriz)
    > Math.sqrt(picToenemyVertic2 * picToenemyVertic2 + picToenemyHoriz2 * picToenemyHoriz2))
    {
        if(Abs(picToenemyHoriz2) < Abs(picToenemyVertic2))
    {
        if(picToenemyVertic2 > 0)
        {
            movingDirection = 3;
        }
        if(picToenemyVertic2 < 0)
        {
            movingDirection = 2;
        }
    }
    else
    {
        if(picToenemyHoriz2 > 0)
        {
            movingDirection = 0;
        }
        if(picToenemyHoriz2 < 0)
        {
            movingDirection = 1;
        }
    }

    moveEnemy();

    checkForEnemyCatching(pic2);
    }
    else
    {
        if(Abs(picToenemyHoriz) < Abs(picToenemyVertic))
    {
        if(picToenemyVertic > 0)
        {
            movingDirection = 3;
        }
        if(picToenemyVertic < 0)
        {
            movingDirection = 2;
        }
    }
    else
    {
        if(picToenemyHoriz > 0)
        {
            movingDirection = 0;
        }
        if(picToenemyHoriz < 0)
        {
            movingDirection = 1;
        }
    }

    moveEnemy();

    checkForEnemyCatching(pic);
    }

    
    
}

function checkForEnemyCatching(hero)
{
    if(overlap(hero,enemy))
    {   
        alert('You lost');
    }
}

function Abs(value)
{
    if(value > 0) return value;
    else return  -value;
}

const overlap = function(sprite1,sprite2)
{
    if(sprite1.x < sprite2.x + sprite2.width
        && sprite1.y < sprite2.y + sprite2.height
        && sprite1.x + sprite1.width > sprite2.x
        && sprite1.y + sprite1.height > sprite2.y)
        {
            return 1;
        }

}

function checkForEatingTheCoin(sprite,coinParam)
{
    if(overlap(sprite,coinParam))
    {   
        coinParam.x = game.rnd.integerInRange(0,700);
        coinParam.y = game.rnd.integerInRange(0,700);
        return true;
    }
    return false;
}

function moveSprite(sprite) {
    if(hasMoved == false)
    {
         pic.animations.stop();
     return;
     }
    


    if (movingDirection == 0)
    sprite.x += 4;
    else  if (movingDirection == 1)
    sprite.x -= 4;
    else  if (movingDirection == 2)
    sprite.y -= 4;
    else  if (movingDirection == 3)
    sprite.y += 4;

    if(touchesWalls(sprite))
    {
        if (movingDirection == 0)
        sprite.x -= 4;
    else  if (movingDirection == 1)
    sprite.x += 4;
    else  if (movingDirection == 2)
    sprite.y += 4;
    else  if (movingDirection == 3)
    sprite.y -= 4;
    }
}

function moveEnemy() {
    
    


    if (movingDirection == 0)
    enemy.x += 2;
    else  if (movingDirection == 1)
    enemy.x -= 2;
    else  if (movingDirection == 2)
    enemy.y -= 2;
    else  if (movingDirection == 3)
    enemy.y += 2;

    if(touchesWalls(enemy))
    {
         if (movingDirection == 0)
    
         {
            enemy.x -= 4;
            enemy.y -= 4;
         }
    
     else  if (movingDirection == 1)
     {

        enemy.x += 4;
        enemy.y += 4;
     }
     else  if (movingDirection == 2)
     {
        enemy.x -= 4;
        enemy.y += 4;
     }
     else  if (movingDirection == 3)
     {
        enemy.x += 4;
        enemy.y -= 4;
     }
    }
}


function handleExitingScreenToTheLeft(sprite) {
    if (sprite.x < 0) {
        sprite.x = 0;
        hasMoved = true;
    }
}

function handleExitingScreenToTheUp(sprite)
{
    if (sprite.y < 0) {
        hasMoved = true;
        sprite.y = 0;
    }
}

function handleExitingScreenToTheDown(sprite)
{
    if (sprite.y + sprite.height> game.height) {
        hasMoved = true;
        sprite.y -= 4;
    }
}

function handleExitingScreenToTheRight(sprite) {
    if (sprite.x + sprite.width> game.width) {
        hasMoved = true;
        sprite.x -= 4;
    }
}
